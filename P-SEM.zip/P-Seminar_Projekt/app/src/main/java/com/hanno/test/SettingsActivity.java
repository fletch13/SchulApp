package com.hanno.test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.ArrayList;

public class SettingsActivity extends AppCompatActivity implements SubjectAdapter.OnItemListener {

    private ArrayList<String> selection = new ArrayList<>();
    private Dialog subjectListDialog;
    private Dialog subNew;
    private View themeSwitch;

    Button btnDeleteSubjects, btnSaveSubject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        subNew = new Dialog(this);
        subNew.setContentView(R.layout.create_subject_dialog);
        subNew.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        subjectListDialog = new Dialog(this);
        subjectListDialog.setContentView(R.layout.subject_list_dialog);
        subjectListDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        btnDeleteSubjects = subjectListDialog.findViewById(R.id.btnDeleteSubjects);
        btnSaveSubject = subjectListDialog.findViewById(R.id.btnSaveSubject);

        /*
        Überprüft die AndroidVersion nach Androidversionen die kleiner als Q sind
        */

        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.Q)
        {
            themeSwitch = findViewById(R.id.themeChange);
            themeSwitch.setVisibility(View.VISIBLE);
        }

    }

    public void resetAll(View view) {
        deleteDatabase(MenuActivity.databaseName);
        SharedPreferences sharedPreferences = getSharedPreferences("firstStart", MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferencesEditor = sharedPreferences.edit();
        sharedPreferencesEditor.putBoolean("firstStart", false);
        sharedPreferencesEditor.apply();
        SharedPreferences preferences = getSharedPreferences("datacheck", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("datacheck", false);
        editor.apply();

        startActivity(new Intent(this, StartActivity.class));
        this.finish();
    }

    public void giveSubjectlist(View view) {
        adaptList(new ArrayList<>());
        subjectListDialog.show();
    }

    public void adaptList(ArrayList<String> pos){
        RecyclerView subjectRecyclerView = subjectListDialog.findViewById(R.id.subjectRecyclerView);
        ArrayList<String> subjects = Subject.getNames();
        SubjectAdapter subjectAdapter = new SubjectAdapter(subjects, this, pos);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        subjectRecyclerView.setLayoutManager(layoutManager);
        subjectRecyclerView.setAdapter(subjectAdapter);
    }

    @Override
    public void onItemClick(int position, String subject) {
        if(btnDeleteSubjects.getText().toString().equals("Löschen")){
            if(!selection.contains(subject)){
                selection.add(subject);
            } else {
                selection.remove(subject);
            }
            adaptList(selection);
        }
    }

    public void changeSubjectlist(View view) {
        Button btnChangeSubjectlist = subjectListDialog.findViewById(R.id.btnChangeSubjectlist);
        LinearLayout llBtnChangeSubjectlist = subjectListDialog.findViewById(R.id.llBtnChangeSubjectlist);
        if(btnChangeSubjectlist.getText().toString().equals("Bearbeiten")){
            btnChangeSubjectlist.setText("Fertig");
            llBtnChangeSubjectlist.setVisibility(View.VISIBLE);
        } else if(btnDeleteSubjects.getText().toString().equals("Entfernen")){
            btnChangeSubjectlist.setText("Bearbeiten");
            llBtnChangeSubjectlist.setVisibility(View.GONE);
        } else {
            btnDeleteSubjects.setText("Entfernen");
            selection.clear();
            adaptList(selection);
        }
    }

    public void deleteSubjects(View view) {
        if(btnDeleteSubjects.getText().toString().equals("Entfernen")){
            btnDeleteSubjects.setText("Löschen");
        } else {
            SQLiteDatabase databaseSubject = getBaseContext().openOrCreateDatabase(MenuActivity.databaseName, MODE_PRIVATE, null);
            for(int i=0;i<selection.size();i++){
                databaseSubject.execSQL("DELETE FROM subject WHERE name = '" + selection.get(i) + "';");
            }
            databaseSubject.close();
            SQLiteDatabase databaseLesson = getBaseContext().openOrCreateDatabase(MenuActivity.databaseName, Context.MODE_PRIVATE, null);
            while (selection.size()>0){
                String shot = Subject.subjects.get(Subject.getNames().indexOf(selection.get(0))).getShortage();
                databaseLesson.execSQL("DELETE FROM lesson WHERE subject = '" + shot + "';");
                while (TimeTable.lessons.contains(shot)){
                    TimeTable.lessons.remove(shot);
                }
                Subject.subjects.remove(Subject.getNames().indexOf(selection.get(0)));
                selection.remove(0);
            }
            databaseLesson.close();
            adaptList(new ArrayList<>());
        }
    }

    public void addSubjects(View view) {
        Button btnSaveSubject = subNew.findViewById(R.id.btnSaveSubject);
        EditText etSubjectName = subNew.findViewById(R.id.etSubjectName);
        EditText etSubjectShortage = subNew.findViewById(R.id.etSubjectShortage);
        etSubjectName.clearComposingText();
        etSubjectShortage.clearComposingText();
        btnSaveSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String subnam = etSubjectName.getText().toString().trim();
                String subsho = etSubjectShortage.getText().toString().trim();
                boolean nam = true;
                boolean sho = true;
                for(String name : Subject.getNames()){
                    if(name.equalsIgnoreCase(subnam)){
                        nam = false;
                    }
                }
                for(String shortage : Subject.getShortages()){
                    if(shortage.equalsIgnoreCase(subsho)){
                        sho = false;
                    }
                }
                if(subnam.equals("")){
                    Toast.makeText(getApplicationContext(), "Der Name des Fachs fehlt", Toast.LENGTH_SHORT).show();
                } else if(subsho.equals("")){
                    Toast.makeText(getApplicationContext(), "Das Kürzel des Fachs fehlt", Toast.LENGTH_SHORT).show();
                } else if(!nam){
                    Toast.makeText(getApplicationContext(), "Der Name existiert bereits", Toast.LENGTH_SHORT).show();
                    etSubjectName.clearComposingText();
                } else if(!sho){
                    Toast.makeText(getApplicationContext(), "Das Kürzel existiert bereits", Toast.LENGTH_SHORT).show();
                    etSubjectShortage.clearComposingText();
                } else {
                    Subject.addSubject(subsho, subnam);
                    SQLiteDatabase databaseSubject = getBaseContext().openOrCreateDatabase(MenuActivity.databaseName, MODE_PRIVATE, null);
                    databaseSubject.execSQL("INSERT INTO subject VALUES('" + subsho + "', '" + subnam + "')");
                    databaseSubject.close();
                    adaptList(new ArrayList<>());
                    subNew.dismiss();
                }
            }
        });
        subNew.show();
    }

    public void saveSubject(View view) {
        EditText tvSubjectName = subNew.findViewById(R.id.etSubjectName);
        EditText etSubjectShortage = subNew.findViewById(R.id.etSubjectShortage);
    }

    public void DarkThemeOn(View view)
    {
        boolean checked = ((CheckBox) view).isChecked();

        if(checked)
        {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
        else
        {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

}