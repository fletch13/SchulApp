package com.hanno.test;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Subject {

    public static ArrayList<Subject> subjects = new ArrayList<>();

    private final String shortage;
    private final String name;

    public Subject(String shortage, String name){
        this.shortage = shortage;
        this.name = name;
    }

    public String getShortage(){
        return shortage;
    }

    public String getName(){
        return name;
    }

    /**
     * fügt subjects ein neues Fach hinzu
     * @param shot das Kürzel des Fachs
     * @param nam der Name des Fachs
     */
    public static void addSubject(String shot, String nam){
        int i;
        int e = 0;
        do{
            i = shot.compareTo(subjects.get(e).getShortage());
            e++;
        } while (i>0 && e<subjects.size());
        if(e<subjects.size()){
            subjects.add(e-1, new Subject(shot, nam));
        } else {
            subjects.add(new Subject(shot, nam));
        }
    }

    public static void sort(){
        ArrayList<Subject> old = new ArrayList<>();
        old.add(Subject.subjects.get(0));
        for(int i=1;i<Subject.subjects.size();i++) {
            int b = 0;
            while (Subject.subjects.get(i).getShortage().compareTo(old.get(b).getShortage()) < 0) {
                b++;
            }
            old.add(b, Subject.subjects.get(i));
        }
        Collections.reverse(old);
        Subject.subjects.clear();
        Subject.subjects.addAll(old);
    }

    /**
     * Erzeugt ein Array aus den Namen in der Arraylist 'subjects'
     * @return Ein String Array aus Fächernamen
     */
    public static ArrayList<String> getNames(){
        ArrayList<String> names = new ArrayList<>();
        for(int i=0; i<subjects.size(); i++){
            names.add(subjects.get(i).getName());
        }
        return names;
    }

    /**
     * Erzeugt ein Array aus den Kürzeln in der Arraylist 'subjects'
     * @return Ein String Array aus Kürzeln
     */
    public static String[] getShortages(){
        String[] shortages = new String[subjects.size()];
        for(int i=0; i<subjects.size(); i++){
            shortages[i] = subjects.get(i).getShortage();
        }
        return shortages;
    }

    /**
     * Füllt die Arraylist 'subjects' mit einer auswahl von Fächern
     */
    public static void initialize(){
        subjects.add(new Subject("B", "Biologie"));
        subjects.add(new Subject("Ch", "Chemie"));
        subjects.add(new Subject("D", "Deutsch"));
        subjects.add(new Subject("E", "Englisch"));
        subjects.add(new Subject("Eth", "Ethik"));
        subjects.add(new Subject("Ev", "Evangelisch"));
        subjects.add(new Subject("F", "Französisch"));
        subjects.add(new Subject("G", "Geschichte"));
        subjects.add(new Subject("Inf", "Informatik"));
        subjects.add(new Subject("Geo", "Geographie"));
        subjects.add(new Subject("K", "Katholisch"));
        subjects.add(new Subject("Ku", "Kunst"));
        subjects.add(new Subject("L", "Latein"));
        subjects.add(new Subject("M", "Mathematik"));
        subjects.add(new Subject("Mu", "Musik"));
        subjects.add(new Subject("Ph", "Physik"));
        subjects.add(new Subject("S", "Spanisch"));
        subjects.add(new Subject("Sk", "Sozialkunde"));
        subjects.add(new Subject("Sp", "Sport"));
        subjects.add(new Subject("Wr", "Wirtschaft"));
    }
}
