package com.hanno.test;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {

    public static final String databaseName = "database.db";
    
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        if(firstAppStart()){
            createDatabase();

            Subject.initialize();
            SQLiteDatabase databaseSubject = getBaseContext().openOrCreateDatabase(databaseName, MODE_PRIVATE, null);
            for(int i=0; i<Subject.subjects.size(); i++){
                databaseSubject.execSQL("INSERT INTO subject VALUES('" + Subject.subjects.get(i).getShortage() + "', '" + Subject.subjects.get(i).getName() + "')");
            }
            databaseSubject.close();
        }
        newAppstart();
        Subject.sort();
    }

    /**
     * Checkt, ob die App das erste Mal auf dem Handy gestartet wird
     * @return wird die App das erste Mal gestartet?
     */
    public boolean firstAppStart(){
        boolean first = false;
        SharedPreferences sharedPreferences = getSharedPreferences("firstStart", MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferencesEditor = sharedPreferences.edit();
        if(!sharedPreferences.getBoolean("firstStart", false)){
            first = true;
            sharedPreferencesEditor.putBoolean("firstStart", true);
            sharedPreferencesEditor.apply();
        }
        return first;
    }

    /**
     * Erzeugt eine neue Datenbank
     */
    public void createDatabase(){
        SQLiteDatabase database = getBaseContext().openOrCreateDatabase(databaseName, MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE event(name TEXT, minute INT, hour INT, day INT, month INT, year INT)");
        database.execSQL("CREATE TABLE subject(shortage TEXT, name TEXT)");
        database.execSQL("CREATE TABLE lesson(position INT, subject TEXT)");
        database.close();
    }

    /**
     * Prüft, ob die App neu gestartet wurde:
     * Wenn dies der Fall ist...
     * ...wird das aktuelle Datum neu bestimmt
     * ...werden die Daten aus der Datenbank geladen
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void newAppstart() {
        SharedPreferences preferences = getSharedPreferences("datacheck", MODE_PRIVATE);
        if(!preferences.getBoolean("datacheck", false)){
            CalendarUtils.selectedDate = LocalDate.now();
            initDatabase();
        } else {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("datacheck", false);
            editor.apply();
        }
    }

    /**
     * Ruft die Events, Subjects und Lessons aus der Datenbank ab und überträgt diese in die entsprechenden Arraylists
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void initDatabase() {
        SQLiteDatabase databaseEvent = getBaseContext().openOrCreateDatabase(databaseName, MODE_PRIVATE, null);
        Cursor cursorEvent = databaseEvent.rawQuery("SELECT COUNT(*) FROM event", null);
        cursorEvent.moveToFirst();
        int countEvent = cursorEvent.getInt(0);
        Cursor cursorCopy = databaseEvent.rawQuery("SELECT * FROM event", null);
        cursorCopy.moveToFirst();
        int e=0;
        while (e<countEvent){
            Event.eventList.add(new Event(cursorCopy.getString(0), cursorCopy.getInt(1), cursorCopy.getInt(2), cursorCopy.getInt(3), cursorCopy.getInt(4), cursorCopy.getInt(5)));
            e = e+1;
            cursorCopy.moveToNext();
        }
        cursorCopy.close();
        cursorEvent.close();
        databaseEvent.close();

        SQLiteDatabase databaseSubject = getBaseContext().openOrCreateDatabase(databaseName, MODE_PRIVATE, null);
        Cursor cursorSubject = databaseSubject.rawQuery("SELECT COUNT(*) FROM subject", null);
        cursorSubject.moveToFirst();
        int countSubject = cursorSubject.getInt(0);
        Cursor cursorCopyer = databaseSubject.rawQuery("SELECT * FROM subject", null);
        cursorCopyer.moveToFirst();
        int s=0;
        while (s<countSubject){
            Subject.subjects.add(new Subject(cursorCopyer.getString(0), cursorCopyer.getString(1)));
            s = s+1;
            cursorCopyer.moveToNext();
        }
        cursorCopyer.close();
        cursorSubject.close();
        databaseSubject.close();

        SQLiteDatabase databaseLesson = getBaseContext().openOrCreateDatabase(databaseName, MODE_PRIVATE, null);
        Cursor cursorLesson = databaseLesson.rawQuery("SELECT COUNT(*) FROM lesson", null);
        cursorLesson.moveToFirst();
        int countLesson = cursorLesson.getInt(0);
        Cursor cursorcopying = databaseLesson.rawQuery("SELECT * FROM lesson", null);
        cursorcopying.moveToFirst();
        int l=0;
        for (int i=0; i<77; i++){
            TimeTable.lessons.add("");
        }
        while (l<countLesson){
            TimeTable.lessons.remove(cursorcopying.getInt(0));
            TimeTable.lessons.add(cursorcopying.getInt(0), cursorcopying.getString(1));
            l = l+1;
            cursorcopying.moveToNext();
        }
        cursorcopying.close();
        cursorLesson.close();
        databaseLesson.close();
    }

    public void openCalendar(View view) {
        startActivity(new Intent(this, MonthViewActivity.class));
        this.finish();
    }

    public void openSettings(View view) {
        startActivity(new Intent(this, SettingsActivity.class));
        this.finish();
    }
}