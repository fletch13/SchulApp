package com.hanno.test;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SubjectAdapter extends RecyclerView.Adapter<SubjectViewHolder> {

    private final ArrayList<String> subjects;
    private final SubjectAdapter.OnItemListener onItemListener;
    private ArrayList<String> pos;

    public SubjectAdapter(ArrayList<String> subjects, OnItemListener onItemListener, ArrayList<String> pos) {
        this.subjects = subjects;
        this.onItemListener = onItemListener;
        this.pos = pos;
    }

    @NonNull
    @Override
    public SubjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.subject_list_cell, parent, false);
        return new SubjectViewHolder(view, onItemListener, subjects);
    }

    @Override
    public void onBindViewHolder(@NonNull SubjectViewHolder holder, int position) {
        final String subject = subjects.get(position);
        if (subject == null)
            holder.listCell.setText("");
        else {
            holder.listCell.setText(subject);
        }
        if(pos.contains(subject)){
            holder.llContainer.setBackgroundColor(Color.LTGRAY);
        }
    }

    @Override
    public int getItemCount() {
        return subjects.size();
    }

    public interface OnItemListener {
        void onItemClick(int position, String subject);
    }
}
