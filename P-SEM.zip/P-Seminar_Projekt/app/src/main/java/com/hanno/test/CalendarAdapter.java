package com.hanno.test;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.hanno.test.R.drawable;

import java.time.LocalDate;
import java.util.ArrayList;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarViewHolder>
{
    private final ArrayList<LocalDate> days;
    private final OnItemListener onItemListener;

    public CalendarAdapter(ArrayList<LocalDate> days, OnItemListener
            onItemListener) {
        this.days = days;
        this.onItemListener = onItemListener;
    }

    @NonNull
    @Override
    public CalendarViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                                 int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.calendar_cell, parent, false);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if(days.size()>15) {
            layoutParams.height = (int) (parent.getHeight() * 0.1666666666);
        }
        else
            layoutParams.height = (int) (parent.getHeight());
        return new CalendarViewHolder(view, onItemListener, days);
    }

    @SuppressLint("SetTextI18n")
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(@NonNull CalendarViewHolder holder, int position) {
        final LocalDate date = days.get(position);
        if(date == null)
            holder.dayOfMonth.setText("");
        else {
            holder.dayOfMonth.setText(String.valueOf(date.getDayOfMonth()));
            if(Event.getEventCountforDate(date) != 0){
                holder.cellDayEvents.setText(Event.getEventCountforDate(date) + " ");
                if(Event.checkObFerien(date)) {
                    holder.dayOfMonth.setBackgroundColor(Color.parseColor("#3E065F"));
                }
                else
                {
                    holder.dayOfMonth.setBackgroundColor(Color.parseColor("#8E05C2"));
                }
            }
            holder.cellDayEvents.setBackgroundColor(Color.parseColor("#700B97"));
            if(date.equals(CalendarUtils.selectedDate))
                holder.dayOfMonth.setBackgroundColor(Color.parseColor("#700B97"));

        }
        if(WeekViewActivity.eft.equals("event")){
            holder.cellDayEvents.setVisibility(View.VISIBLE);
        } else {
            holder.cellDayEvents.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return days.size();
    }

    public interface OnItemListener {
        void onItemClick(int position, LocalDate date);
    }
}
